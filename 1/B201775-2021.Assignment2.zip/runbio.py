#!/usr/local/bin/python3
import os
from biofunction import motif_scan,blast
from tools import motif_stool,multi,merge,assemble,get_species


def run():
    while True:       #loop for the whole programme
        q = input('Welcome to my bioinformatics study programme!\n'
                 'It provides sequence searching and analysis for protein functions and species that YOU WANT.\n'
                 'However, it has a length maximum for 150 sequences.   ''\n'
                 'Type ANYTHING to start the programme ''\n'
                 'Type "q" to quit''\n'
                 '> ').lower()
        if q == 'q':
            break

        merge_back = 's' #setting the state not allow the first yild programme go back
        while True:                #loop for the first choice
            print('Please choose the searching mode  ')
            switch = input("   0: will repeat and each time is new protein and species;\n"
                           "   1: will repeat for same protein and different species;\n"
                           "   2: will repeat for different proteins and same specices\n"
                           "   Press q to quit\n"
                           "   others(like p,*,7...) will only search once\n>: ").lower()
            if switch == 'q':
                break
            names = locals()  # get changing variables
            g = multi(switch,merge_back)    # connect to some function with ’yield‘ and if merge_back is 'b' it will run from the initial position
            count = 0
            f0, names['a'+ str(count)], length, dic = next(g)    #[f0:Para, a0:seqence content, length: numberof sequence,dic:dictionary]
            merge_back = 's'             # set the back indicator to normal or it will never go into the mode loop
            if switch == '0' or switch == '1' or switch == '2':
               while q != 'q':             #loop for statisfaction to the present results
                   count += 1
                   names['a' + str(count)], lem, dim = next(g)[1:]
                   length += lem
                   dic.update(dim)
                   if length == 0:
                       continue
                   elif length > 150:        # length limitation
                       print('Too much sequences, think more about the running time.')
                       break
                   q = input('>> Do you want to continue adding? Press q to quit\n> ').lower()
               print('The total sequences are {0}, including {1} species '.format(length,len(dic.keys())))
               for i in get_species(dic):
                   x = ' : '.join(i)
                   print(x)
               merge_back=input('>>Do you want to continue to merge? Press b to get back\n> ').lower()
               if merge_back == 'b':
                   continue
               print('merging...')
               mg = merge(list(names['a' + str(i)] for i in range(0, count + 1)))
               print('merging completed')
               break
            else:
                if length == 0 or length >150:
                    continue
                d = input('>>Do you want to continue to merge? Press b to go back\n> ').lower()
                if d == 'b':
                    continue
                mg = merge(list(names['a' + str(count)]))
                print('merging completed')
                break

        if switch == 'q':
            continue
        else:
            # I think clustering and plotting do not need to go back
            q = input('>> Do you want to do clustering? Press q to skip\n> ').lower()
            if q != 'q':
                print('clustering...')
                clustfn=f0.clust()
                print('Similarity plot generating...')
                f0.plotting(clustfn)
                print('Done')
                cl = input(">> Do you want to save clustering output file? Press s to save").lower()
                if cl == 's':
                    print('{} saved!'.format(clustfn))
                else:
                    os.system('rm -f {}'.format(clustfn))
                    print('{} deleted!'.format(clustfn))

            # I think motif scanning don't need either
            q = input('>> Do you want to do motif scanning? Press q to skip\n> ').lower()
            if q != 'q':
                ms = motif_stool('merge.fa')
                while True:
                    try:
                        file = next(ms)
                        motif_scan()
                    except StopIteration:
                        print('Scanning finished')
                        os.system('rm -f 1.fa')
                        os.system('rm -f 0.motif')
                        # os.system('rm -f clusted.fa')
                        p = input('>> Do you want to save all the searched sequences? Press s to save \n > ').lower()
                        if p !='s':
                            os.system('rm -f merge.fa')
                            print('merge.fa is deleted!')
                        else:
                            print('merge.fa saved!')
                        break

            # use blast to check the similar sequence
            q=input(">> Do you want to do check the similarity of single sequence (based on your search)? Press q to skip\n> ").lower()
            if q != 'q':
                for i in get_species(dic):
                    x = ' : '.join(i)
                    print(x)
                while True:
                    try:
                        sn = input('Please enter its specise name:\n> ').lower()
                        sn = sn[0].upper() + sn[1:]
                        id = input('Please enter its id:\n> ').upper()
                        fn=assemble(dic,sn,id)
                        print('Blasting........')
                        blast(fn)
                        bl = input(">> Do you want to save the seqeunce? Press s to save").lower()
                        if bl == 's':
                            print('File saved!')
                        else:
                            os.system('rm -f {}.fa'.format(id))
                            print('File deleted!')
                        break
                    except IndexError:
                        print('Please enter the correct information')
                        continue
                    except KeyError :
                        print('Please enter the correct information')
                        continue

            q=input('Thank you for using! Press q to quit, press anything to start again.').lower()
            if q == 'q':
                break

run()

